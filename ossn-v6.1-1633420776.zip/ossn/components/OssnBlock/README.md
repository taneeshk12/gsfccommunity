OssnBlock
==========

Allow users to block other users.

Blocked user can't:

* Access Profile
* Send message
* View users wall posts
* Comment on user wall post (post only  , entities support not added yet)
* Block them viewing user blogs, videos, events, polls, posts.
